import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  Alert,
  StyleSheet,
  ScrollView,
  FlatList,
} from 'react-native';

type Props = {
  navigation: any;
  setMenuItems: (items: any) => void;
  menuItems: any[];
  COURSES: string[];
};

export default function AddItemScreen({ navigation, setMenuItems, menuItems, COURSES }: Props) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState('');

  // helper function - a named TypeScript function
  function resetForm() {
    setName('');
    setDescription('');
    setPrice('');
    setCategory('');
  }

  // add item function (updates the array stored in App state via prop)
  function addItem() {
    if (!name.trim() || !description.trim() || !price || !category) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }

    const priceValue = parseFloat(price);
    if (isNaN(priceValue) || priceValue <= 0) {
      Alert.alert('Error', 'Enter a valid price');
      return;
    }

    const newItem = {
      id: Date.now().toString(),
      name: name.trim(),
      description: description.trim(),
      price: priceValue,
      category,
    };

    // update using functional set to avoid state closure issues
    setMenuItems((prev: any[]) => [...prev, newItem]);
    Alert.alert('Added', `${newItem.name} added to ${newItem.category}`);
    resetForm();
    navigation.navigate('Menu');
  }

  // remove item by id - accessible to chef in this screen
  function removeItemById(id: string) {
    setMenuItems((prev: any[]) => prev.filter((i) => i.id !== id));
    Alert.alert('Removed', 'Menu item removed');
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16 }}>
      <Pressable onPress={() => navigation.goBack()} style={styles.back}>
        <Text style={styles.backText}>← Back</Text>
      </Pressable>

      <Text style={styles.title}>Add Menu Item</Text>

      <View style={styles.formCard}>
        <Text style={styles.label}>Dish Name</Text>
        <TextInput value={name} onChangeText={setName} style={styles.input} placeholder="e.g., Lemon Chicken" placeholderTextColor="#999" />

        <Text style={[styles.label, { marginTop: 12 }]}>Description</Text>
        <TextInput value={description} onChangeText={setDescription} style={[styles.input, { height: 80 }]} multiline placeholder="Short description" placeholderTextColor="#999" />

        <Text style={[styles.label, { marginTop: 12 }]}>Price</Text>
        <TextInput value={price} onChangeText={(t) => setPrice(t.replace(/[^0-9.]/g, ''))} style={styles.input} keyboardType="decimal-pad" placeholder="e.g., 79.50" placeholderTextColor="#999" />

        <Text style={[styles.label, { marginTop: 12 }]}>Course</Text>
        <View style={styles.categoriesRow}>
          {COURSES.map((c) => (
            <Pressable
              key={c}
              onPress={() => setCategory(c)}
              style={[styles.catBtn, category === c && styles.catBtnSelected]}
            >
              <Text style={[styles.catText, category === c && styles.catTextSelected]}>{c}</Text>
            </Pressable>
          ))}
        </View>

        <View style={{ flexDirection: 'row', marginTop: 16 }}>
          <Pressable style={[styles.button, { marginRight: 8 }]} onPress={() => navigation.goBack()}>
            <Text style={styles.buttonText}>Cancel</Text>
          </Pressable>

          <Pressable style={[styles.button, styles.addButton]} onPress={addItem}>
            <Text style={[styles.buttonText, { color: '#000' }]}>Add Item</Text>
          </Pressable>
        </View>
      </View>

      {/* Current items list with remove option for chef */}
      <View style={{ marginTop: 18 }}>
        <Text style={styles.sectionTitle}>Current Menu Items</Text>
        {menuItems.length === 0 ? (
          <Text style={styles.empty}>No items yet</Text>
        ) : (
          <FlatList
            data={menuItems}
            keyExtractor={(i) => i.id}
            scrollEnabled={false} 
            renderItem={({ item }) => (
              <View style={styles.itemRow}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.itemName}>{item.name}</Text>
                  <Text style={styles.itemMeta}>{item.category} • R{Number(item.price).toFixed(2)}</Text>
                </View>
                <Pressable onPress={() => removeItemById(item.id)} style={styles.removeBtn}>
                  <Text style={styles.removeText}>Remove</Text>
                </Pressable>
              </View>
            )}
            ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
          />
        )}
      </View>

      <View style={{ height: 48 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: '#1A1A1A',
    flex: 1,
  },
  back: {
    marginBottom: 8,
    paddingLeft: 4,
  },
  backText: {
    color: '#0096FF',
    fontFamily: 'serif',
  },
  title: {
    color: '#FFFFFF',
    fontSize: 22,
    fontFamily: 'serif',
    fontWeight: '700',
    marginBottom: 8,
  },
  formCard: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
  },
  label: {
    color: '#CFCFCF',
    fontFamily: 'serif',
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#111111',
    color: '#FFFFFF',
    padding: 10,
    borderRadius: 6,
    marginTop: 6,
    borderWidth: 1,
    borderColor: '#333333',
    fontFamily: 'serif',
  },
  categoriesRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginTop: 8,
  },
  catBtn: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#1F1F1F',
    borderRadius: 12,
    marginRight: 8,
    marginBottom: 8,
  },
  catBtnSelected: {
    backgroundColor: '#0096FF',
  },
  catText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
  },
  catTextSelected: {
    color: '#000000',
    fontFamily: 'serif',
  },
  button: {
    flex: 1,
    padding: 12,
    backgroundColor: '#808080',
    borderRadius: 8,
    alignItems: 'center',
  },
  addButton: {
    backgroundColor: '#FFD34D', 
  },
  buttonText: {
    fontFamily: 'serif',
    color: '#FFFFFF',
    fontWeight: '700',
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
    marginBottom: 8,
  },
  empty: {
    color: '#CFCFCF',
  },
  itemRow: {
    backgroundColor: '#2A2A2A',
    padding: 10,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  itemName: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
  },
  itemMeta: {
    color: '#CFCFCF',
    marginTop: 4,
  },
  removeBtn: {
    backgroundColor: '#FF4D4D',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    marginLeft: 10,
  },
  removeText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
  },
});

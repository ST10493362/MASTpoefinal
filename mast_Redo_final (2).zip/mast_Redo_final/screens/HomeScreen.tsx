import React, { useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
  ScrollView,
  StyleSheet,
} from 'react-native';

type Props = {
  navigation: any;
  isChef: boolean;
  menuItems: any[];
  setIsChef: (b: boolean) => void;
  COURSES: string[];
};

export default function HomeScreen({
  navigation,
  isChef,
  menuItems,
  setIsChef,
  COURSES,
}: Props) {
  // Calculate average prices by course
  // Demonstrates: for loop, while loop, for...in loop and helper function usage

  const calculateAverages = (items: any[], courses: string[]) => {
    // Using a for loop to create totals/counts
    const totals: { [key: string]: { sum: number; count: number } } = {};
    for (let i = 0; i < courses.length; i++) {
      totals[courses[i]] = { sum: 0, count: 0 };
    }

    // while loop to iterate items array and accumulate
    let idx = 0;
    while (idx < items.length) {
      const it = items[idx];
      if (it && totals[it.category]) {
        totals[it.category].sum += Number(it.price);
        totals[it.category].count += 1;
      }
      idx++;
    }

    // for...in loop to compute averages from totals
    const averages: { [key: string]: number } = {};
    for (const k in totals) {
      const entry = totals[k];
      averages[k] = entry.count > 0 ? parseFloat((entry.sum / entry.count).toFixed(2)) : 0;
    }

    return averages;
  };

  const averages = useMemo(() => calculateAverages(menuItems, COURSES), [menuItems, COURSES]);

  function renderItem({ item }: { item: any }) {
    return (
      <View style={styles.card}>
        <View style={styles.cardContent}>
          <Text style={styles.itemTitle}>{item.name}</Text>
          <Text style={styles.itemDesc}>{item.description}</Text>
          <Text style={styles.itemMeta}>
            {item.category} • R{Number(item.price).toFixed(2)}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ padding: 16 }}>
      <View style={styles.headerRow}>
        <Image source={require('../assets/home.png')} style={styles.logo} />
        <Text style={styles.title}>Christoffel Cooks</Text>
      </View>

      <View style={styles.statsCard}>
        <Text style={styles.statText}>Total Menu Items: {menuItems.length}</Text>
        <TouchableOpacity
          style={styles.menuButton}
          onPress={() => navigation.navigate('Menu')}
        >
          <Text style={styles.menuButtonText}>View Menu</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.loginButton}
          onPress={() => (isChef ? setIsChef(false) : navigation.navigate('Login'))}
        >
          <Text style={styles.loginButtonText}>{isChef ? 'Chef Logout' : 'Chef Login'}</Text>
        </TouchableOpacity>

        {isChef && (
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => navigation.navigate('AddItem')}
          >
            <Text style={styles.addButtonText}>Add Menu Item</Text>
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.avgCard}>
        <Text style={styles.sectionTitle}>Average Price by Course</Text>
        {COURSES.map((c) => (
          <View key={c} style={styles.avgRow}>
            <Text style={styles.avgCourse}>{c}</Text>
            <Text style={styles.avgValue}>
              {averages[c] > 0 ? `R${averages[c].toFixed(2)}` : '—'}
            </Text>
          </View>
        ))}
      </View>

      <View style={{ marginTop: 12 }}>
        <Text style={styles.sectionTitle}>Complete Menu</Text>
        {menuItems.length === 0 ? (
          <Text style={styles.emptyText}>No menu items yet.</Text>
        ) : (
          <FlatList
            data={menuItems}
            keyExtractor={(i) => i.id}
            renderItem={renderItem}
            scrollEnabled={false} // main ScrollView handles scrolling
            ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
          />
        )}
      </View>
      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: '#1A1A1A',
    flex: 1,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  logo: {
    width: 64,
    height: 64,
    marginRight: 12,
    borderRadius: 8,
  },
  title: {
    fontSize: 28,
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
  },
  statsCard: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  statText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginBottom: 8,
    fontFamily: 'serif',
  },
  menuButton: {
    backgroundColor: '#0096FF',
    paddingVertical: 10,
    borderRadius: 6,
    marginBottom: 8,
    alignItems: 'center',
  },
  menuButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontFamily: 'serif',
  },
  loginButton: {
    backgroundColor: '#808080',
    paddingVertical: 8,
    borderRadius: 6,
    marginBottom: 8,
    alignItems: 'center',
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
  },
  addButton: {
    backgroundColor: '#00A6FF',
    paddingVertical: 10,
    borderRadius: 6,
    alignItems: 'center',
  },
  addButtonText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '600',
  },
  avgCard: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    marginBottom: 8,
    fontFamily: 'serif',
    fontWeight: '700',
  },
  avgRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomColor: '#3A3A3A',
    borderBottomWidth: 1,
  },
  avgCourse: {
    color: '#FFFFFF',
    fontFamily: 'serif',
  },
  avgValue: {
    color: '#0096FF',
    fontFamily: 'serif',
  },
  card: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
  },
  cardContent: {},
  itemTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'serif',
    fontWeight: '700',
  },
  itemDesc: {
    color: '#CFCFCF',
    marginTop: 4,
    fontFamily: 'serif',
  },
  itemMeta: {
    color: '#808080',
    marginTop: 8,
    fontFamily: 'serif',
  },
  emptyText: {
    color: '#CFCFCF',
    paddingTop: 8,
  },
});

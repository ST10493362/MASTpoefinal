import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, Alert, StyleSheet } from 'react-native';

type Props = {
  navigation: any;
  setIsChef: (isChef: boolean) => void;
};

export default function LoginScreen({ navigation, setIsChef }: Props) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  function handleLogin() {
    // simple demo auth
    if (username === 'chef' && password === '123') {
      setIsChef(true);
      Alert.alert('Success', 'Chef login successful');
      navigation.navigate('Home');
    } else {
      Alert.alert('Error', 'Invalid credentials');
    }
  }

  return (
    <View style={styles.screen}>
      <Pressable onPress={() => navigation.goBack()} style={{ marginBottom: 12 }}>
        <Text style={styles.back}>← Back</Text>
      </Pressable>

      <Text style={styles.title}>Chef Login</Text>

      <Text style={styles.label}>Username</Text>
      <TextInput value={username} onChangeText={setUsername} style={styles.input} placeholder="chef" placeholderTextColor="#999" autoCapitalize="none" />

      <Text style={[styles.label, { marginTop: 12 }]}>Password</Text>
      <TextInput value={password} onChangeText={setPassword} style={styles.input} placeholder="123" placeholderTextColor="#999" secureTextEntry />

      <Pressable onPress={handleLogin} style={[styles.button, { marginTop: 16 }]}>
        <Text style={styles.buttonText}>Login as Chef</Text>
      </Pressable>

      <View style={{ marginTop: 18 }}>
        <Text style={styles.demoTitle}>Demo Credentials</Text>
        <Text style={styles.demoText}>Username: chef</Text>
        <Text style={styles.demoText}>Password: 123</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    backgroundColor: '#1A1A1A',
    flex: 1,
    padding: 16,
  },
  back: {
    color: '#0096FF',
    fontFamily: 'serif',
  },
  title: {
    color: '#FFFFFF',
    fontSize: 22,
    fontFamily: 'serif',
    fontWeight: '700',
    marginBottom: 12,
  },
  label: {
    color: '#CFCFCF',
    fontFamily: 'serif',
    fontWeight: '600',
    marginBottom: 6,
  },
  input: {
    backgroundColor: '#111111',
    color: '#FFFFFF',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#333333',
    fontFamily: 'serif',
  },
  button: {
    backgroundColor: '#0096FF',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
  },
  demoTitle: {
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
    marginBottom: 6,
  },
  demoText: {
    color: '#CFCFCF',
  },
});

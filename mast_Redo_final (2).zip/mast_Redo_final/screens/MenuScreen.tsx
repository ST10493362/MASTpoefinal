import React, { useState } from 'react';
import {
  View,
  Text,
  FlatList,
  Pressable,
  StyleSheet,
} from 'react-native';

type Props = {
  navigation: any;
  menuItems: any[];
  isChef: boolean;
  COURSES: string[];
};

export default function MenuScreen({ navigation, menuItems, isChef, COURSES }: Props) {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const cats = ['All', ...COURSES];

  const filteredItems = selectedCategory === 'All'
    ? menuItems
    : menuItems.filter(item => item.category === selectedCategory);

  const renderMenuItem = ({ item }: { item: any }) => (
    <View style={styles.menuItem}>
      <Text style={styles.itemName}>{item.name}</Text>
      <Text style={styles.itemDescription}>{item.description}</Text>
      <View style={styles.itemFooter}>
        <Text style={styles.itemPrice}>R{Number(item.price).toFixed(2)}</Text>
        <Text style={styles.itemCategory}>{item.category}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.screen}>
      <Pressable
        style={styles.backButton}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backButtonText}>← Back</Text>
      </Pressable>

      <Text style={styles.title}>Menu</Text>
      <Text style={styles.subtitle}>Total Items: {menuItems.length}</Text>

      <View style={styles.filterRow}>
        {cats.map(category => (
          <Pressable
            key={category}
            style={[
              styles.categoryButton,
              selectedCategory === category && styles.categoryButtonSelected
            ]}
            onPress={() => setSelectedCategory(category)}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === category && styles.categoryTextSelected
            ]}>
              {category}
            </Text>
          </Pressable>
        ))}
      </View>

      <FlatList
        data={filteredItems}
        renderItem={renderMenuItem}
        keyExtractor={item => item.id}
        style={{ marginTop: 12 }}
        contentContainerStyle={{ paddingBottom: 40 }}
      />

      {isChef && (
        <Pressable
          style={styles.addNew}
          onPress={() => navigation.navigate('AddItem')}
        >
          <Text style={styles.addNewText}>+ Add New Item</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    padding: 16,
    backgroundColor: '#1A1A1A',
  },
  backButton: {
    marginBottom: 6,
  },
  backButtonText: {
    fontSize: 16,
    color: '#0096FF',
  },
  title: {
    fontSize: 24,
    color: '#FFFFFF',
    fontFamily: 'serif',
    fontWeight: '700',
    marginBottom: 4,
  },
  subtitle: {
    color: '#CFCFCF',
    marginBottom: 10,
  },
  filterRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  categoryButton: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#2A2A2A',
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  categoryButtonSelected: {
    backgroundColor: '#0096FF',
  },
  categoryText: {
    color: '#FFFFFF',
    fontFamily: 'serif',
  },
  categoryTextSelected: {
    color: '#FFFFFF',
    fontFamily: 'serif',
  },
  menuItem: {
    backgroundColor: '#2A2A2A',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  itemName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontFamily: 'serif',
    fontWeight: '700',
  },
  itemDescription: {
    color: '#CFCFCF',
    marginTop: 6,
    fontFamily: 'serif',
  },
  itemFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  itemPrice: {
    color: '#0096FF',
    fontWeight: '700',
    fontFamily: 'serif',
  },
  itemCategory: {
    color: '#CFCFCF',
    backgroundColor: '#1F1F1F',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
    fontFamily: 'serif',
  },
  addNew: {
    position: 'absolute',
    right: 16,
    bottom: 20,
    backgroundColor: '#0096FF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 30,
  },
  addNewText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontFamily: 'serif',
  },
});
